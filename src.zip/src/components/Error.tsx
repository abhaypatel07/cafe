const ErrorPage = (error: any) => {
  return <div>Opps... Something got wrong</div>;
};

export default ErrorPage;
