export const USERS = "IcpUXD_bm_user_index";
export const USER_META_DATA = "IcpUXD_usermeta";
export const POSTS_META_DATA = "IcpUXD_postmeta";
export const TERM_TAXONOMY = "IcpUXD_term_taxonomy";
export const TERM_RELATIONSHIPS = "IcpUXD_term_relationships";
export const POSTS = "IcpUXD_posts";
export const MATERIALS = "materials";
