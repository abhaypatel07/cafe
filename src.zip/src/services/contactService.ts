import React from "react";

export const contactService = () => {
  const US_PHONE_NUMBER = "(+1) 646-760-7371";
  const ISRAEL_PHONE_NUMBER = "(+972) 50-973-697397";
  return {
    US_PHONE_NUMBER,
    ISRAEL_PHONE_NUMBER,
  };
};
