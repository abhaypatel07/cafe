export interface Lesson {
  thumbnail_url: string;
  date: string;
  lesson_number: number;
  title?: string;
  record_link?: string;
  quiz_id?: string;
}
