export interface Student {
  id?: string;
  avatar?: string;
  name?: string;
}
